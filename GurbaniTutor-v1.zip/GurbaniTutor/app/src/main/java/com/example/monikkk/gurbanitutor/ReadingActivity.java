package com.example.monikkk.gurbanitutor;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.view.MotionEvent;
import android.view.GestureDetector;
import android.support.v4.view.GestureDetectorCompat;
import android.media.MediaPlayer;
import android.view.View;
import android.widget.Button;

import java.io.IOException;
import java.io.InputStream;


public class ReadingActivity extends AppCompatActivity implements GestureDetector.OnGestureListener,GestureDetector.OnDoubleTapListener {
    private TextView tv1,tv4;
    private TextView tv2,tv3;
    public int angNo;
    public int lineNo;
    private GestureDetectorCompat gdc1;
    private MediaPlayer mp;
    private String mpfile;
    Button play;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reading);

        play=(Button)findViewById(R.id.button2);
        //pause=(Button)findViewById(R.id.button);
        tv1=(TextView) findViewById(R.id.textView8);
        tv2=(TextView) findViewById(R.id.textView10);
        tv3=(TextView) findViewById(R.id.textView11);
        tv4=(TextView) findViewById(R.id.textView6);
        this.gdc1=new GestureDetectorCompat(this,this);
        gdc1.setOnDoubleTapListener(this);

        mp= MediaPlayer.create(this,R.raw.a1);

        // Font path
        String fontPath = "fonts/AMRLIPI.TTF";

        // text view label
        TextView txtGhost1 = (TextView) findViewById(R.id.textView10);
        TextView txtGhost2 = (TextView) findViewById(R.id.textView8);
        // Loading Font Face
        Typeface tf = Typeface.createFromAsset(getAssets(), fontPath);

        // Applying font
        txtGhost1.setTypeface(tf);
        txtGhost2.setTypeface(tf);

        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

            @Override
            public void onCompletion(MediaPlayer mp) {
                mp.release();
                tv1.setText(R.string.l2);
                tv2.setText(R.string.l3);
                tv3.setText(R.string.m2);
                onNext(); //method to load the next audio file to mediaplayer;
            }
        });

        /*/Creating a Database;
        DataBaseHelper myDbHelper ;//= new DataBaseHelper();//Context);
        myDbHelper = new DataBaseHelper(this);

        try {

            myDbHelper.createDataBase();

        } catch (IOException ioe) {

            throw new Error("Unable to create database");

        }

        try {

            myDbHelper.openDataBase();
            tv4.setText(R.string.databasedone);

        }catch(SQLException sqle){

            throw sqle;

        }

        //angNo=1;
        lineNo=1;
        String dbString = "";
        SQLiteDatabase db = getW
        String query = "SELECT LINE FROM LineTable WHERE _id = " + lineNo + ";";
        Cursor c = */


    }
    public void onNext()
    {
        mp = MediaPlayer.create(this, R.raw.a2);
        mp.start();
    }

    public void playButtonMethod(View view)
    {mp.start();
     play.setText("||");
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pauseButtonMethod(view);
            }
        });
    }

    public void pauseButtonMethod(View view)
    {mp.pause();
        play.setText("|>");
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playButtonMethod(view);
            }
        });
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        mp.pause();
        play.setText("|>");
        return true;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        mp.start();
        play.setText("||");
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return true;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return true;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return true;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return true;
    }

    @Override
    public void onLongPress(MotionEvent e) {
    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return true;
    }

    /*public void onCompletion(MediaPlayer mp){
        tv1.setText("@string/l2");
        tv2.setText("@string/l3");
        tv3.setText("@string/m2");
       // mp.prepare();
        mp.start();

    }*/

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.gdc1.onTouchEvent(event);
        return super.onTouchEvent(event);
    }
}